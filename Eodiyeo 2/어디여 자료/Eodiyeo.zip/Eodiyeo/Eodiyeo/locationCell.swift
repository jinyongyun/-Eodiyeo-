//
//  locationCell.swift
//  Eodiyeo
//
//  Created by jinyong yun on 1/3/24.
//

import UIKit

class locationCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var subtitleLabel: UILabel!
}
